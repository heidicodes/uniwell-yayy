import React from 'react';

// Component disabled for modern theme
export const Marquee: React.FC<{text: string}> = () => {
  return null;
};
