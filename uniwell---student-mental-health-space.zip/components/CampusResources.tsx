import React from 'react';
import { CampusResource } from '../types';
import { PhoneIcon } from './icons/PhoneIcon';
import { BuildingIcon } from './icons/BuildingIcon';
import { ClockIcon } from './icons/ClockIcon';

const resources: CampusResource[] = [
  {
    title: 'University Counseling Center',
    description: 'Confidential individual and group counseling, workshops, and psychiatric services.',
    contact: 'Phone: (555) 123-4567 | Location: Student Wellness Bldg, Room 210',
    icon: BuildingIcon,
  },
  {
    title: '24/7 Crisis Hotline',
    description: 'Immediate, confidential support for students in crisis or emotional distress.',
    contact: 'Phone: (555) 765-4321 (Call or Text)',
    icon: PhoneIcon,
  },
  {
    title: 'Academic Success Center',
    description: 'Support for stress related to academic performance, test anxiety, and time management.',
    contact: 'Location: Library, First Floor',
    icon: BuildingIcon,
  },
  {
    title: 'After-Hours Support',
    description: 'Provides access to a mental health professional when the counseling center is closed.',
    contact: 'Phone: (555) 123-4567, press 2',
    icon: ClockIcon,
  },
   {
    title: 'Student Health Services',
    description: 'Medical services that can address physical symptoms related to mental health.',
    contact: 'Location: Health Center, Building C',
    icon: BuildingIcon,
  },
    {
    title: 'Disability Resource Center',
    description: 'Provides accommodations for students with documented mental health conditions.',
    contact: 'Phone: (555) 987-6543',
    icon: PhoneIcon,
  },
];

const ResourceCard: React.FC<{ resource: CampusResource }> = ({ resource }) => (
  <div className="bg-white rounded-2xl p-6 flex items-start space-x-4 transition-all duration-300 border border-slate-200 hover:border-indigo-300 hover:shadow-sm">
    <div className="flex-shrink-0 h-14 w-14 rounded-full bg-green-100 flex items-center justify-center">
      <resource.icon className="h-7 w-7 text-green-700" />
    </div>
    <div>
      <h3 className="text-lg font-bold text-slate-800">{resource.title}</h3>
      <p className="text-slate-600 mt-1">{resource.description}</p>
      <p className="text-sm text-indigo-600 mt-2 font-semibold">{resource.contact}</p>
    </div>
  </div>
);

const CampusResources: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="font-fredoka text-4xl font-bold mb-2 text-slate-800">Campus Resources</h1>
      <p className="text-slate-500 mb-6">You're not alone. Help is available right here on campus.</p>
      <div className="grid gap-6 md:grid-cols-2">
        {resources.map((resource, index) => (
          <ResourceCard key={index} resource={resource} />
        ))}
      </div>
    </div>
  );
};

export default CampusResources;