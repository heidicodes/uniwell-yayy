import React, { useState } from 'react';
import { Habit, HabitCategory } from '../types';
import { TrashIcon } from './icons/TrashIcon';

interface HabitTrackerProps {
    addXp: (amount: number) => void;
}

const initialHabitData: HabitCategory[] = [
  {
    title: 'Hygiene',
    habits: [
      { id: 'h1', name: 'Brush teeth twice a day', completions: {} },
      { id: 'h2', name: 'Take a daily shower', completions: {} },
    ],
  },
  {
    title: 'Activity',
    habits: [
      { id: 'a1', name: 'Go for a 20-minute walk', completions: {} },
      { id: 'a2', name: 'Stretch for 10 minutes', completions: {} },
    ],
  },
  {
    title: 'Sleep',
    habits: [
      { id: 's1', name: 'Be in bed by 11 PM', completions: {} },
      { id: 's2', name: 'No screens 30 mins before bed', completions: {} },
    ],
  },
  {
    title: 'Food Habits',
    habits: [
      { id: 'f1', name: 'Drink 8 glasses of water', completions: {} },
      { id: 'f2', name: 'Eat 3 servings of fruit/veg', completions: {} },
    ],
  },
  {
    title: 'Social Activity',
    habits: [
      { id: 'so1', name: 'Connect with a friend or family', completions: {} },
    ],
  },
  {
    title: 'My Quests',
    habits: [],
  },
];


const HabitTracker: React.FC<HabitTrackerProps> = ({ addXp }) => {
    const [habitCategories, setHabitCategories] = useState<HabitCategory[]>(initialHabitData);
    const [newHabitName, setNewHabitName] = useState('');

    const getWeekDays = () => {
        const today = new Date();
        const currentDay = today.getDay();
        const weekStart = new Date(today);
        const dayOffset = (currentDay === 0) ? 6 : currentDay - 1;
        weekStart.setDate(today.getDate() - dayOffset);

        return Array.from({ length: 7 }).map((_, i) => {
            const day = new Date(weekStart);
            day.setDate(weekStart.getDate() + i);
            return day;
        });
    };
    
    const formatDate = (date: Date): string => {
        return date.toISOString().split('T')[0];
    };

    const weekDays = getWeekDays();

    const handleAddHabit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newHabitName.trim()) return;
        const newHabit: Habit = {
            id: Date.now().toString(),
            name: newHabitName,
            completions: {},
        };
        
        setHabitCategories(prevCategories => 
            prevCategories.map(category => {
                if (category.title === "My Quests") {
                    return {
                        ...category,
                        habits: [...category.habits, newHabit]
                    };
                }
                return category;
            })
        );
        setNewHabitName('');
    };

    const handleDeleteHabit = (categoryTitle: string, habitId: string) => {
        setHabitCategories(prevCategories =>
            prevCategories.map(category => {
                if (category.title === categoryTitle) {
                    return {
                        ...category,
                        habits: category.habits.filter(h => h.id !== habitId),
                    };
                }
                return category;
            })
        );
    };

    const handleToggleCompletion = (categoryTitle: string, habitId: string, date: Date) => {
        const dateKey = formatDate(date);
        setHabitCategories(prevCategories =>
            prevCategories.map(category => {
                if (category.title === categoryTitle) {
                    return {
                        ...category,
                        habits: category.habits.map(habit => {
                            if (habit.id === habitId) {
                                const newCompletions = { ...habit.completions };
                                if (newCompletions[dateKey]) {
                                    delete newCompletions[dateKey];
                                } else {
                                    newCompletions[dateKey] = true;
                                    addXp(5);
                                }
                                return { ...habit, completions: newCompletions };
                            }
                            return habit;
                        }),
                    };
                }
                return category;
            })
        );
    };

    return (
        <div className="max-w-4xl mx-auto">
            <h1 className="font-fredoka text-4xl font-bold mb-2 text-slate-800">Daily Quests</h1>
            <p className="text-slate-500 mb-6">Complete daily quests for XP and build positive routines.</p>
            
            <div className="bg-white rounded-2xl shadow-sm p-6 mb-8 border border-slate-200">
                <form onSubmit={handleAddHabit} className="flex flex-col sm:flex-row items-center gap-3">
                    <input
                        type="text"
                        value={newHabitName}
                        onChange={(e) => setNewHabitName(e.target.value)}
                        placeholder="Add a new quest to 'My Quests'"
                        className="flex-1 w-full p-3 border border-slate-300 rounded-xl bg-slate-50 focus:ring-2 focus:ring-indigo-300 focus:outline-none transition"
                    />
                    <button
                        type="submit"
                        disabled={!newHabitName.trim()}
                        className="w-full sm:w-auto bg-indigo-500 text-white font-bold py-3 px-5 rounded-xl hover:bg-indigo-600 disabled:bg-slate-300 transition-colors"
                    >
                        Add Quest
                    </button>
                </form>
            </div>

            <div className="space-y-8">
                {habitCategories.map(category => (
                     <div key={category.title} className="bg-white rounded-2xl shadow-sm p-6 border border-slate-200">
                        <h2 className="font-fredoka text-2xl font-bold text-slate-700 mb-4">{category.title}</h2>
                        <div className="space-y-4">
                            {category.habits.map(habit => (
                                <div key={habit.id} className="bg-slate-50 rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row items-center justify-between gap-4 border border-slate-200">
                                    <span className="font-semibold text-slate-800 text-center sm:text-left">{habit.name}</span>
                                    <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
                                        {weekDays.map(day => {
                                            const isCompleted = habit.completions[formatDate(day)];
                                            return (
                                                <button
                                                    key={day.toISOString()}
                                                    onClick={() => handleToggleCompletion(category.title, habit.id, day)}
                                                    className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-bold text-sm transition-all duration-200 border-2 transform hover:scale-110 ${
                                                        isCompleted
                                                            ? 'bg-teal-300 text-white border-teal-400'
                                                            : 'bg-white hover:bg-slate-100 border-slate-300'
                                                    }`}
                                                    aria-label={`Mark ${habit.name} as ${isCompleted ? 'incomplete' : 'complete'} for ${day.toLocaleDateString()}`}
                                                >
                                                    {day.toLocaleDateString('en-US', { weekday: 'narrow' })}
                                                </button>
                                            );
                                        })}
                                        {category.title === "My Quests" && (
                                            <button onClick={() => handleDeleteHabit(category.title, habit.id)} className="ml-2 p-2 rounded-full text-slate-400 hover:bg-red-100 hover:text-red-600 transition" aria-label={`Delete habit: ${habit.name}`}>
                                                <TrashIcon className="w-5 h-5" />
                                            </button>
                                        )}
                                    </div>
                                </div>
                            ))}
                            {category.habits.length === 0 && (
                                <div className="text-center py-4">
                                    <p className="text-slate-500">Add a new quest above to get started!</p>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default HabitTracker;