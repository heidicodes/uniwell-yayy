import React from 'react';
import { MoodIcon } from './icons/MoodIcon';
import { ChatIcon } from './icons/ChatIcon';
import { ResourcesIcon } from './icons/ResourcesIcon';
import { ExerciseIcon } from './icons/ExerciseIcon';
import { HabitTrackerIcon } from './icons/HabitTrackerIcon';
import { FindASpotIcon } from './icons/FindASpotIcon';
import { Page } from '../App';

interface HomePageProps {
  setActivePage: (page: Page) => void;
}

const features = [
  {
    page: 'mood' as Page,
    title: 'Mood Power-Up',
    description: 'Log your mood to gain XP and track your emotional journey.',
    icon: MoodIcon,
    color: 'bg-green-100',
    textColor: 'text-green-700',
  },
  {
    page: 'habits' as Page,
    title: 'Daily Quests',
    description: 'Complete daily habits to earn XP and build powerful routines.',
    icon: HabitTrackerIcon,
    color: 'bg-yellow-100',
    textColor: 'text-yellow-700',
  },
  {
    page: 'exercises' as Page,
    title: 'Mental Health Exercises',
    description: 'Level up your mind with guided exercises for focus and calm.',
    icon: ExerciseIcon,
    color: 'bg-red-100',
    textColor: 'text-red-700',
  },
  {
    page: 'chat' as Page,
    title: 'Anonymous Chat',
    description: 'Connect with a supportive guide in a safe, anonymous chat.',
    icon: ChatIcon,
    color: 'bg-pink-100',
    textColor: 'text-pink-700',
  },
  {
    page: 'spots' as Page,
    title: 'Find a Spot',
    description: 'Explore new places on campus to relax, study, or connect.',
    icon: FindASpotIcon,
    color: 'bg-fuchsia-100',
    textColor: 'text-fuchsia-700',
  },
  {
    page: 'resources' as Page,
    title: 'Campus Resources',
    description: 'Find helpful info and support services available at university.',
    icon: ResourcesIcon,
    color: 'bg-sky-100',
    textColor: 'text-sky-700',
  },
];

const FeatureCard: React.FC<{
  feature: typeof features[0];
  onClick: () => void;
}> = ({ feature, onClick }) => (
  <button
    onClick={onClick}
    className="bg-white rounded-2xl p-6 text-left w-full h-full flex flex-col items-start transition-all duration-300 border border-slate-200 hover:border-indigo-300 hover:shadow-sm"
  >
    <div className={`flex-shrink-0 h-16 w-16 rounded-xl ${feature.color} flex items-center justify-center`}>
      <feature.icon className={`h-8 w-8 ${feature.textColor}`} />
    </div>
    <h3 className={`font-fredoka text-xl font-bold mt-4 text-slate-800`}>{feature.title}</h3>
    <p className="text-slate-500 mt-1 text-sm flex-grow">{feature.description}</p>
    <div className={`mt-4 text-md font-bold ${feature.textColor}`}>
      Start →
    </div>
  </button>
);

const HomePage: React.FC<HomePageProps> = ({ setActivePage }) => {
  return (
    <div className="max-w-5xl mx-auto text-center">
      <h1 className="font-fredoka text-6xl font-extrabold mb-2 text-slate-800 tracking-wide">Welcome to UniWell!</h1>
      <p className="text-slate-500 mb-10 text-lg">Your adventure in mental wellness starts now.</p>
      
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {features.map((feature) => (
          <FeatureCard key={feature.page} feature={feature} onClick={() => setActivePage(feature.page)} />
        ))}
         <div className="bg-blue-50 rounded-2xl p-6 w-full flex flex-col items-center text-center lg:col-span-3 md:col-span-2 border border-blue-100">
            <h4 className="font-fredoka font-bold text-blue-800">Mindful Moment</h4>
            <p className="text-blue-700 mt-2">"Even small steps forward are still progress. Keep going, you're doing great!"</p>
        </div>
      </div>
    </div>
  );
};

export default HomePage;