import React from 'react';
import { MoodIcon } from './icons/MoodIcon';
import { ChatIcon } from './icons/ChatIcon';
import { ResourcesIcon } from './icons/ResourcesIcon';
import { ExerciseIcon } from './icons/ExerciseIcon';
import { LogoIcon } from './icons/LogoIcon';
import { HabitTrackerIcon } from './icons/HabitTrackerIcon';
import { HomeIcon } from './icons/HomeIcon';

type Page = 'home' | 'mood' | 'chat' | 'resources' | 'exercises' | 'habits';

interface SidebarProps {
  activePage: Page;
  setActivePage: (page: Page) => void;
}

const NavItem: React.FC<{
  page: Page;
  activePage: Page;
  setActivePage: (page: Page) => void;
  icon: React.ReactNode;
  label: string;
}> = ({ page, activePage, setActivePage, icon, label }) => {
  const isActive = activePage === page;
  return (
    <li>
      <button
        onClick={() => setActivePage(page)}
        className={`flex items-center p-3 my-1 w-full text-base font-normal rounded-lg transition duration-75 group ${
          isActive
            ? 'bg-indigo-100 text-indigo-700'
            : 'text-slate-500 hover:bg-indigo-100 hover:text-indigo-700'
        }`}
      >
        {icon}
        <span className="ml-3 hidden md:block">{label}</span>
      </button>
    </li>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ activePage, setActivePage }) => {
  return (
    <aside className="w-16 md:w-64 h-full" aria-label="Sidebar">
      <div className="overflow-y-auto h-full py-4 px-3 bg-white border-r border-indigo-100">
        <div className="flex items-center pl-2.5 mb-5">
          <LogoIcon className="h-8 w-8 text-indigo-500" />
          <span className="self-center text-xl font-semibold whitespace-nowrap text-slate-800 ml-2 hidden md:block">
            UniWell
          </span>
        </div>
        <ul className="space-y-2">
          <NavItem 
            page="home"
            activePage={activePage}
            setActivePage={setActivePage}
            icon={<HomeIcon className="w-6 h-6" />}
            label="Home"
          />
          <NavItem 
            page="mood"
            activePage={activePage}
            setActivePage={setActivePage}
            icon={<MoodIcon className="w-6 h-6" />}
            label="Mood Check-in"
          />
          <NavItem 
            page="chat"
            activePage={activePage}
            setActivePage={setActivePage}
            icon={<ChatIcon className="w-6 h-6" />}
            label="Anonymous Chat"
          />
          <NavItem 
            page="resources"
            activePage={activePage}
            setActivePage={setActivePage}
            icon={<ResourcesIcon className="w-6 h-6" />}
            label="Campus Resources"
          />
          <NavItem 
            page="exercises"
            activePage={activePage}
            setActivePage={setActivePage}
            icon={<ExerciseIcon className="w-6 h-6" />}
            label="Wellness Exercises"
          />
          <NavItem
            page="habits"
            activePage={activePage}
            setActivePage={setActivePage}
            icon={<HabitTrackerIcon className="w-6 h-6" />}
            label="Habit Tracker"
          />
        </ul>
      </div>
    </aside>
  );
};

export default Sidebar;