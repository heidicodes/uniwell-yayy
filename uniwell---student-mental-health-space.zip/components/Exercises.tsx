import React, { useState, useEffect, useRef } from 'react';
import { Exercise, JournalEntry } from '../types';

interface ExercisesProps {
    addXp: (amount: number) => void;
}

const exercises: Exercise[] = [
  {
    title: 'Box Breathing',
    description: 'A simple technique to calm your nervous system and reduce stress.',
    duration: '5 Minutes',
    content: [
      'Find a comfortable, quiet place to sit.',
      'Close your eyes and breathe in slowly through your nose for a count of four.',
      'Hold your breath for a count of four.',
      'Exhale slowly through your mouth for a count of four.',
      'Hold your breath for a count of four.',
      'Repeat this cycle for 5 minutes, focusing on the sensation of your breath.',
    ],
  },
  {
    title: '5-4-3-2-1 Grounding',
    description: 'An exercise to bring you back to the present moment during anxiety.',
    duration: '3 Minutes',
    content: [
      'Take a deep breath to begin.',
      'Acknowledge 5 things you can see around you. It could be a pen, a spot on the ceiling, anything.',
      'Acknowledge 4 things you can touch around you. Feel the texture of your clothing, the smooth surface of a table.',
      'Acknowledge 3 things you can hear. This could be the hum of a computer, birds chirping, or traffic.',
      'Acknowledge 2 things you can smell. Maybe the smell of a coffee, or a book.',
      'Acknowledge 1 thing you can taste. Take a sip of water or notice the current taste in your mouth.',
      'End with another deep breath.',
    ],
  },
  {
    title: 'Guided Meditation',
    description: 'Focus your mind and find inner peace with this guided session.',
    duration: '10 Minutes',
    content: [
      'Find a comfortable and quiet seated position.',
      'Gently close your eyes and bring your attention to your breath.',
      'Notice the sensation of the air entering your nostrils and filling your lungs.',
      'As you exhale, let go of any tension in your shoulders, jaw, and brow.',
      'If your mind wanders, gently guide it back to your breath without judgment.',
      'Continue this for the duration. When thoughts arise, simply observe them like clouds passing in the sky.',
      'When you are ready, slowly bring your awareness back to the room and open your eyes.'
    ],
  },
  {
    title: 'Body Scan Meditation',
    description: 'Connect with your body and release tension by focusing on physical sensations.',
    duration: '10 Minutes',
    content: [
        'Lie down comfortably on your back, with your arms by your sides and legs uncrossed.',
        'Gently close your eyes and take a few deep breaths, allowing your body to begin to relax.',
        'Bring your attention to the toes of your left foot. Notice any sensations—warmth, tingling, pressure—without judgment.',
        'Slowly scan your awareness up your left leg, through your foot, ankle, shin, and thigh, simply observing any sensations.',
        'Repeat this process for your right leg, starting with your toes and moving up.',
        'Continue this scan up through your torso, arms, hands, neck, and face, paying gentle attention to each part of your body.',
        'If your mind wanders, gently guide it back to the part of the body you are focusing on.',
        'Once you have scanned your entire body, rest for a moment in full-body awareness before slowly returning to your day.'
    ],
  },
    {
    title: 'Gratitude Journal',
    description: 'Focus on the positive by noting what you are thankful for.',
    duration: '5 Minutes',
    content: [
      'Settle into a comfortable position and take a moment to be present.',
      'Prompt 1: What are three small things that brought you joy today? (e.g., a sunny moment, a good song)',
      'Prompt 2: Think of a person in your life you are grateful for. What specific quality do you appreciate most about them?',
      'Prompt 3: Reflect on a recent challenge. What is one thing you learned from it that you can be grateful for?',
      'Prompt 4: What is something about your environment or surroundings that you are thankful for today?',
      'Take a final moment to feel the warmth of gratitude before you finish.',
    ],
  },
  {
    title: 'Guided Journaling',
    description: 'A space to write down your thoughts and feelings without judgment.',
    duration: '10 Minutes',
    content: [
        'Find a quiet space and take a few deep breaths to settle in.',
        'Consider this prompt: "How am I truly feeling in this moment? What is taking up space in my mind?" Write freely.',
        'Reflect on your day. "What was one challenge I faced, and how did I handle it?"',
        'Think about gratitude. "What is one thing, big or small, that I am grateful for today?"',
        'Look ahead. "What is one small, kind thing I can do for myself tomorrow?"',
        'Read over what you wrote. There is no need to judge it. Just acknowledge your thoughts and thank yourself for this time.',
    ]
  }
];

const BreathingTimer: React.FC<{}> = () => {
    const [phase, setPhase] = useState<'Breathe In' | 'Hold' | 'Breathe Out' | 'Hold'>('Breathe In');
    const [countdown, setCountdown] = useState(4);
    const [isActive, setIsActive] = useState(false);
    const intervalRef = useRef<number | null>(null);

    const phases: ('Breathe In' | 'Hold' | 'Breathe Out' | 'Hold')[] = ['Breathe In', 'Hold', 'Breathe Out', 'Hold'];

    useEffect(() => {
        if (isActive) {
            intervalRef.current = window.setInterval(() => {
                setCountdown(prev => {
                    if (prev > 1) {
                        return prev - 1;
                    } else {
                        setPhase(currentPhase => {
                            const nextIndex = (phases.indexOf(currentPhase) + 1) % phases.length;
                            return phases[nextIndex];
                        });
                        return 4;
                    }
                });
            }, 1000);
        } else {
            if (intervalRef.current) clearInterval(intervalRef.current);
        }
        return () => {
            if (intervalRef.current) clearInterval(intervalRef.current);
        };
    }, [isActive]);
    
    const handleStart = () => setIsActive(true);
    const handleStop = () => {
        setIsActive(false);
        setPhase('Breathe In');
        setCountdown(4);
    }
    
    const getCircleClass = () => {
        if (!isActive) return 'scale-100';
        switch(phase) {
            case 'Breathe In': return 'scale-110';
            case 'Breathe Out': return 'scale-100';
            default: return '';
        }
    }

    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className={`relative w-48 h-48 sm:w-64 sm:h-64 rounded-full bg-sky-100 flex items-center justify-center transition-transform duration-[4000ms] ease-in-out border-2 border-sky-200 ${getCircleClass()}`}>
                <div className="text-center">
                    <p className="text-2xl font-semibold text-sky-800">{phase}</p>
                    <p className="text-5xl font-bold text-sky-600">{countdown}</p>
                </div>
            </div>
            <div className="mt-8 flex space-x-4">
                <button onClick={isActive ? handleStop : handleStart} className="w-28 bg-indigo-500 text-white font-bold py-3 px-4 rounded-xl hover:bg-indigo-600 transition-colors">
                    {isActive ? 'Stop' : 'Start'}
                </button>
            </div>
        </div>
    );
};

const musicOptions = [
  { name: 'Rain', src: 'https://cdn.pixabay.com/audio/2022/10/20/audio_16157f12c1.mp3' },
  { name: 'Forest', src: 'https://cdn.pixabay.com/audio/2022/08/17/audio_394a233267.mp3' },
  { name: 'Waves', src: 'https://cdn.pixabay.com/audio/2023/09/20/audio_5517173aea.mp3' },
];

const ExerciseModal: React.FC<{ 
    exercise: Exercise; 
    onClose: () => void;
    onSaveJournal: (content: string, type: 'guided' | 'gratitude') => void;
    onCompleteExercise: () => void;
}> = ({ exercise, onClose, onSaveJournal, onCompleteExercise }) => {
    const [journalText, setJournalText] = useState('');
    const audioRef = useRef<HTMLAudioElement | null>(null);
    const [currentMusic, setCurrentMusic] = useState<string | null>(null);

    useEffect(() => {
        if (currentMusic) {
            if (!audioRef.current) {
                audioRef.current = new Audio(currentMusic);
                audioRef.current.loop = true;
            } else {
                audioRef.current.src = currentMusic;
            }
            audioRef.current.play().catch(e => console.error("Audio play failed:", e));
        } else if (audioRef.current) {
            audioRef.current.pause();
        }
    }, [currentMusic]);

    useEffect(() => {
        return () => {
            if (audioRef.current) {
                audioRef.current.pause();
                audioRef.current = null;
            }
        };
    }, []);

    const handleMusicSelect = (src: string) => {
        setCurrentMusic(prevSrc => (prevSrc === src ? null : src));
    };
    
    const handleSave = () => {
        if (journalText.trim()) {
            const type = exercise.title === 'Guided Journaling' ? 'guided' : 'gratitude';
            onSaveJournal(journalText, type);
            setJournalText('');
        }
    }
    
    const isJournal = exercise.title.toLowerCase().includes('journal');

    const renderContent = () => {
        if (exercise.title === 'Box Breathing') return <BreathingTimer />;
        
        return (
             <div className="space-y-3">
                {exercise.content.map((step, index) => (
                    <div key={index} className="flex items-start">
                        <div className="flex-shrink-0 h-6 w-6 rounded-full bg-indigo-100 flex items-center justify-center mr-3">
                            <span className="text-sm font-bold text-indigo-700">{index + 1}</span>
                        </div>
                        <p className="text-slate-600">{step}</p>
                    </div>
                ))}
            </div>
        );
    }
    
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4" onClick={onClose}>
            <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg p-6 relative max-h-[90vh] overflow-y-auto border border-slate-200" onClick={(e) => e.stopPropagation()}>
                <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-700">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
                <h2 className="font-fredoka text-3xl font-bold mb-2 text-slate-800">{exercise.title}</h2>
                <p className="text-slate-600 font-semibold mb-4 bg-yellow-100 text-yellow-800 inline-block px-2 py-1 rounded-md">{exercise.duration}</p>
                {renderContent()}

                {exercise.title === 'Guided Meditation' && (
                    <div className="mt-6 pt-4 border-t border-slate-200">
                        <h4 className="font-bold text-slate-700 mb-3">Background Music</h4>
                        <div className="flex flex-wrap gap-2">
                            {musicOptions.map(option => (
                                <button
                                    key={option.name}
                                    onClick={() => handleMusicSelect(option.src)}
                                    className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${
                                        currentMusic === option.src
                                            ? 'bg-indigo-500 text-white'
                                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                                    }`}
                                >
                                    {option.name}
                                </button>
                            ))}
                        </div>
                    </div>
                )}
                
                {isJournal ? (
                    <div className="mt-6 pt-4 border-t border-slate-200">
                         <textarea
                            value={journalText}
                            onChange={(e) => setJournalText(e.target.value)}
                            placeholder="Start writing here..."
                            className="w-full p-3 border border-slate-300 rounded-xl bg-slate-50 focus:ring-2 focus:ring-indigo-300 focus:outline-none transition"
                            rows={8}
                        />
                        <button onClick={handleSave} className="mt-4 w-full bg-indigo-500 text-white font-bold py-3 px-4 rounded-xl hover:bg-indigo-600 disabled:bg-slate-300 transition-colors">
                            Save Entry (+15 XP)
                        </button>
                    </div>
                ) : (
                    <div className="mt-6 pt-4 border-t border-slate-200">
                        <button onClick={onCompleteExercise} className="w-full bg-indigo-500 text-white font-bold py-3 px-4 rounded-xl hover:bg-indigo-600 transition-colors">
                            Complete (+20 XP)
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

const Exercises: React.FC<ExercisesProps> = ({ addXp }) => {
    const [selectedExercise, setSelectedExercise] = useState<Exercise | null>(null);
    const [guidedJournalEntries, setGuidedJournalEntries] = useState<JournalEntry[]>([]);
    const [gratitudeJournalEntries, setGratitudeJournalEntries] = useState<JournalEntry[]>([]);

    useEffect(() => {
        try {
            const savedGuided = localStorage.getItem('guidedJournalEntries');
            if (savedGuided) setGuidedJournalEntries(JSON.parse(savedGuided));
    
            const savedGratitude = localStorage.getItem('gratitudeJournalEntries');
            if (savedGratitude) setGratitudeJournalEntries(JSON.parse(savedGratitude));
        } catch (error) {
            console.error("Failed to load journal entries from localStorage", error);
        }
    }, []);

    useEffect(() => {
        try {
            localStorage.setItem('guidedJournalEntries', JSON.stringify(guidedJournalEntries));
            localStorage.setItem('gratitudeJournalEntries', JSON.stringify(gratitudeJournalEntries));
        } catch (error) {
            console.error("Failed to save journal entries to localStorage", error);
        }
    }, [guidedJournalEntries, gratitudeJournalEntries]);

    const handleSaveJournal = (content: string, type: 'guided' | 'gratitude') => {
        const newEntry: JournalEntry = {
            id: new Date().toISOString(),
            content,
            date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
        };
        if (type === 'guided') {
            setGuidedJournalEntries([newEntry, ...guidedJournalEntries]);
        } else {
            setGratitudeJournalEntries([newEntry, ...gratitudeJournalEntries]);
        }
        addXp(15);
        setSelectedExercise(null);
    };

    const handleCompleteExercise = () => {
        addXp(20);
        setSelectedExercise(null);
    }
  
    return (
        <div className="max-w-4xl mx-auto">
            <h1 className="font-fredoka text-4xl font-bold mb-2 text-slate-800">Mental Health Exercises</h1>
            <p className="text-slate-500 mb-6">Guided exercises to improve your focus and sense of calm.</p>
            <div className="grid gap-6 md:grid-cols-2">
            {exercises.map((exercise, index) => (
                <div key={index} onClick={() => setSelectedExercise(exercise)} className="bg-white rounded-2xl p-6 cursor-pointer transition-all duration-300 border border-slate-200 hover:border-indigo-300 hover:shadow-sm">
                    <h3 className="text-xl font-bold text-slate-800">{exercise.title}</h3>
                    <p className="text-slate-600 mt-1 text-sm">{exercise.description}</p>
                    <div className="mt-4 text-sm font-semibold text-yellow-800 bg-yellow-100 inline-block px-3 py-1 rounded-full">
                        {exercise.duration}
                    </div>
                </div>
            ))}
            </div>
            {selectedExercise && <ExerciseModal exercise={selectedExercise} onClose={() => setSelectedExercise(null)} onSaveJournal={handleSaveJournal} onCompleteExercise={handleCompleteExercise} />}

            {guidedJournalEntries.length > 0 && (
                <div className="mt-12">
                    <h2 className="font-fredoka text-3xl font-bold mb-4 text-slate-700">Guided Journal Entries</h2>
                    <div className="space-y-6">
                        {guidedJournalEntries.map(entry => (
                            <div key={entry.id} className="bg-white rounded-2xl p-6 border border-slate-200">
                                <p className="text-sm font-semibold text-indigo-600 mb-2">{entry.date}</p>
                                <p className="text-slate-700 whitespace-pre-wrap">{entry.content}</p>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {gratitudeJournalEntries.length > 0 && (
                <div className="mt-12">
                    <h2 className="font-fredoka text-3xl font-bold mb-4 text-slate-700">Gratitude Journal Entries</h2>
                    <div className="space-y-6">
                        {gratitudeJournalEntries.map(entry => (
                            <div key={entry.id} className="bg-white rounded-2xl p-6 border border-slate-200">
                                <p className="text-sm font-semibold text-pink-600 mb-2">{entry.date}</p>
                                <p className="text-slate-700 whitespace-pre-wrap">{entry.content}</p>
                            </div>
                        ))}
                    </div>
                </div>
            )}
        </div>
    );
};

export default Exercises;