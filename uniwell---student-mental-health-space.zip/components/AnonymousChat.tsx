import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { getAIResponse } from '../services/geminiService';
import { UserIcon } from './icons/UserIcon';
import { SparklesIcon } from './icons/SparklesIcon';

const AnonymousChat: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const aiResponseText = await getAIResponse(messages, input);
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: aiResponseText,
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiMessage]);
    } catch (error) {
      const errorMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: 'Sorry, I encountered an error. Please try again.',
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full max-w-3xl mx-auto bg-white rounded-2xl shadow-sm border border-slate-200">
      <div className="p-4 border-b border-slate-200">
        <h1 className="font-fredoka text-2xl font-bold text-slate-800">Anonymous Chat</h1>
        <p className="text-sm text-slate-500">You are connected with a wellness guide.</p>
      </div>
      <div className="flex-1 p-6 overflow-y-auto bg-slate-50">
        <div className="space-y-6">
            {messages.length === 0 && !isLoading && (
                <div className="text-center text-slate-500 p-4 bg-white rounded-lg">
                    <p className="font-semibold">How can I help you today?</p>
                    <p className="text-xs mt-2">All conversations are confidential and anonymous.</p>
                </div>
            )}
            {messages.map((message) => (
                <div key={message.id} className={`flex items-end gap-3 ${message.sender === 'user' ? 'justify-end' : ''}`}>
                {message.sender === 'ai' && (
                    <div className="w-10 h-10 rounded-full bg-indigo-200 flex items-center justify-center flex-shrink-0 border-2 border-white shadow-sm">
                        <SparklesIcon className="w-6 h-6 text-indigo-700" />
                    </div>
                )}
                <div className={`p-3 max-w-sm rounded-2xl shadow-sm ${
                    message.sender === 'user' ? 'bg-slate-800 text-white rounded-br-lg' : 'bg-slate-100 text-slate-700 rounded-bl-lg'
                }`}>
                    <p className="text-sm">{message.text}</p>
                </div>
                {message.sender === 'user' && (
                     <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center flex-shrink-0 border-2 border-white shadow-sm">
                        <UserIcon className="w-6 h-6 text-slate-600" />
                    </div>
                )}
                </div>
            ))}
            {isLoading && (
                 <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-indigo-200 flex items-center justify-center flex-shrink-0">
                        <SparklesIcon className="w-6 h-6 text-indigo-700" />
                    </div>
                    <div className="p-3 rounded-2xl bg-slate-200">
                        <div className="flex items-center justify-center space-x-1">
                            <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse [animation-delay:-0.3s]"></div>
                            <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse [animation-delay:-0.15s]"></div>
                            <div className="w-2 h-2 bg-slate-500 rounded-full animate-pulse"></div>
                        </div>
                    </div>
                </div>
            )}
          <div ref={messagesEndRef} />
        </div>
      </div>
      <div className="p-4 border-t border-slate-200 bg-white rounded-b-2xl">
        <form onSubmit={handleSend} className="flex items-center space-x-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 p-3 border border-slate-300 rounded-xl bg-slate-50 focus:ring-2 focus:ring-indigo-300 focus:outline-none transition"
            disabled={isLoading}
          />
          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="bg-indigo-500 text-white font-bold py-3 px-5 rounded-xl hover:bg-indigo-600 disabled:bg-slate-300 transition-colors"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
};

export default AnonymousChat;