import React, { useState } from 'react';
import { MoodLog } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

type Mood = 'awful' | 'bad' | 'okay' | 'good' | 'great';

interface MoodCheckInProps {
  addXp: (amount: number) => void;
}

const moodOptions: { mood: Mood; emoji: string; color: string }[] = [
  { mood: 'awful', emoji: '😭', color: 'text-red-500' },
  { mood: 'bad', emoji: '😞', color: 'text-orange-500' },
  { mood: 'okay', emoji: '😐', color: 'text-yellow-500' },
  { mood: 'good', emoji: '😊', color: 'text-green-400' },
  { mood: 'great', emoji: '😁', color: 'text-teal-400' },
];

const moodToValue = {
    'awful': 1,
    'bad': 2,
    'okay': 3,
    'good': 4,
    'great': 5,
};

const MoodCheckIn: React.FC<MoodCheckInProps> = ({ addXp }) => {
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [note, setNote] = useState('');
  const [moodHistory, setMoodHistory] = useState<MoodLog[]>([]);
  const [confirmationMessage, setConfirmationMessage] = useState<string | null>(null);

  const handleSelectMood = (mood: Mood) => {
    setSelectedMood(mood);
    setConfirmationMessage(null);
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedMood) {
      const newLog: MoodLog = {
        mood: selectedMood,
        note,
        date: new Date(),
      };
      setMoodHistory([...moodHistory, newLog]);
      addXp(10);
      
      let message = "Thank you for checking in. You've earned +10 XP!";
      setConfirmationMessage(message);

      setSelectedMood(null);
      setNote('');
    }
  };

  const chartData = moodHistory.map(log => ({
      name: log.date.toLocaleDateString('en-US', { month: 'short', day: 'numeric'}),
      mood: moodToValue[log.mood]
  }));

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="font-fredoka text-4xl font-bold mb-2 text-slate-800">Mood Power-Up</h1>
      <p className="text-slate-500 mb-6">Log your mood to gain XP and track your journey.</p>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-8">
        {confirmationMessage && (
            <div className="bg-green-100 border border-green-200 text-green-800 p-4 rounded-xl mb-6 text-center font-semibold">
                <p>{confirmationMessage}</p>
            </div>
        )}
        <form onSubmit={handleSubmit}>
          <h2 className="font-fredoka text-2xl font-bold mb-4 text-center text-slate-700">How are you feeling right now?</h2>
          <div className="flex justify-center space-x-2 sm:space-x-4 mb-6">
            {moodOptions.map(({ mood, emoji, color }) => (
              <button
                key={mood}
                type="button"
                onClick={() => handleSelectMood(mood)}
                className={`p-2 sm:p-4 rounded-full transition-transform duration-200 ease-in-out text-4xl sm:text-6xl ${
                  selectedMood === mood ? 'transform scale-125 ring-4 ring-teal-300' : 'hover:scale-110'
                }`}
              >
                <span className={color}>{emoji}</span>
              </button>
            ))}
          </div>

          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Add a note to your log... (Optional)"
            className="w-full p-3 border border-slate-300 rounded-xl bg-slate-50 focus:ring-2 focus:ring-indigo-300 focus:outline-none transition"
            rows={3}
          />
          <button
            type="submit"
            disabled={!selectedMood}
            className="mt-4 w-full bg-indigo-500 text-white font-bold py-3 px-4 rounded-xl hover:bg-indigo-600 disabled:bg-slate-300 transition-colors"
          >
            Log Mood
          </button>
        </form>
      </div>
      
      {moodHistory.length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
            <h2 className="font-fredoka text-2xl font-bold mb-4 text-slate-700">Your Mood History</h2>
            <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.2} />
                        <XAxis dataKey="name" />
                        <YAxis domain={[1, 5]} tickFormatter={(value) => moodOptions[value-1]?.emoji || ''} />
                        <Tooltip contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '0.75rem' }} />
                        <Line type="monotone" dataKey="mood" stroke="#818cf8" strokeWidth={3} activeDot={{ r: 8, stroke: '#4f46e5', strokeWidth: 2 }} />
                    </LineChart>
                </ResponsiveContainer>
            </div>
        </div>
      )}
    </div>
  );
};

export default MoodCheckIn;