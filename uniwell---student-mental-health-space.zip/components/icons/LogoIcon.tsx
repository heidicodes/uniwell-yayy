
import React from 'react';

export const LogoIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm-1.125 4.5a.75.75 0 00-1.5 0v2.25c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5h-.75V6.5zm3.75 0a.75.75 0 00-1.5 0v2.25c0 .414.336.75.75.75h1.5a.75.75 0 000-1.5h-.75V6.5zM12 18a4.5 4.5 0 004.1-2.437.75.75 0 10-1.3-.724A3 3 0 0112 16.5a3 3 0 01-2.8-1.66.75.75 0 10-1.3.723A4.5 4.5 0 0012 18z" />
    </svg>
);
