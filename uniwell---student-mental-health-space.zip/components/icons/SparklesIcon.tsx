
import React from 'react';

export const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
        <path d="M10.894 2.553a1 1 0 00-1.788 0l-1 1.732a1 1 0 00.52 1.365l1.732 1a1 1 0 001.365-.52l1-1.732a1 1 0 000-1.788l-1.732-1a1 1 0 00-1.365.52zM10 18a1 1 0 01-1-1v-2a1 1 0 112 0v2a1 1 0 01-1 1zM2 11a1 1 0 011-1h2a1 1 0 110 2H3a1 1 0 01-1-1zM14 11a1 1 0 011-1h2a1 1 0 110 2h-2a1 1 0 01-1-1zM4.93 4.93a1 1 0 011.414 0L7.76 6.344a1 1 0 11-1.414 1.414L4.93 6.343a1 1 0 010-1.414zM12.24 12.24a1 1 0 011.414 0l1.414 1.414a1 1 0 11-1.414 1.414l-1.414-1.414a1 1 0 010-1.414z" />
    </svg>
);
