import React from 'react';

export const CafeIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 18h2m-4-5h6a2 2 0 012 2v3H7v-3a2 2 0 012-2zm0 0V5a2 2 0 012-2h2a2 2 0 012 2v8m-6 0h.01M15 5h.01"></path>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13h14v3a2 2 0 01-2 2H7a2 2 0 01-2-2v-3z"></path>
    </svg>
);