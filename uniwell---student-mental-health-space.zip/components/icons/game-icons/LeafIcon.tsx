import React from 'react';

export const LeafIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg className={className} fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
        <path fillRule="evenodd" d="M6 2a.5.5 0 00-.47.33L5 4H4a2 2 0 00-2 2v1h1V6a1 1 0 011-1h12a1 1 0 011 1v9a1 1 0 01-1 1H4a1 1 0 01-1-1v-1H2v1a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1.53c.1-.54.23-1.07.33-1.61a.5.5 0 00-.94-.32A13.01 13.01 0 006 2zM3 8a1 1 0 011-1h4.586a1 1 0 01.707.293l1.414 1.414a1 1 0 01.293.707V15a1 1 0 01-1 1H4a1 1 0 01-1-1V8z" clipRule="evenodd" />
    </svg>
);
