import React from 'react';
import { LogoIcon } from './icons/LogoIcon';
import { HomeIcon } from './icons/HomeIcon';
import { XPIcon } from './icons/XPIcon';
import { Page } from '../App';

interface GameHUDProps {
  activePage: Page;
  level: number;
  xp: number;
  xpToNextLevel: number;
  setActivePage: (page: Page) => void;
}

const GameHUD: React.FC<GameHUDProps> = ({ activePage, level, xp, xpToNextLevel, setActivePage }) => {
  const progressPercentage = (xp / xpToNextLevel) * 100;

  return (
    <header className="bg-white/80 backdrop-blur-sm sticky top-0 z-40 w-full border-b border-slate-200">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo and App Name - Always Visible */}
          <div className="flex items-center gap-3">
            <LogoIcon className="h-9 w-9 text-indigo-500" />
            <span className="font-fredoka text-2xl font-bold text-slate-800">UniWell</span>
          </div>

          {/* Conditional Game Elements and Home Button */}
          {activePage !== 'home' && (
            <div className="flex items-center gap-4 sm:gap-6">
              {/* Level and XP Info */}
              <div className="hidden sm:flex items-center gap-4 sm:gap-6">
                 <div className="flex items-center gap-2">
                    <div className="w-12 h-12 rounded-full bg-purple-200 flex items-center justify-center font-fredoka text-xl font-bold text-purple-800 border-2 border-white shadow-sm">
                        {level}
                    </div>
                    <div>
                        <p className="font-bold text-slate-700 text-sm">LEVEL</p>
                        <p className="text-xs text-slate-500">Your Rank</p>
                    </div>
                 </div>
                 <div className="w-32 sm:w-48">
                    <div className="flex justify-between items-center mb-1">
                        <div className="flex items-center gap-1">
                            <XPIcon className="w-4 h-4 text-teal-500" />
                            <span className="font-bold text-sm text-slate-700">XP</span>
                        </div>
                        <span className="text-xs font-semibold text-slate-500">{xp} / {xpToNextLevel}</span>
                    </div>
                    <div className="w-full bg-slate-200 rounded-full h-2.5">
                        <div className="bg-teal-400 h-2.5 rounded-full" style={{ width: `${progressPercentage}%` }}></div>
                    </div>
                 </div>
              </div>

              {/* Home Button */}
              <div>
                <button
                  onClick={() => setActivePage('home')}
                  className="flex items-center py-2 px-4 text-base font-bold rounded-lg transition-colors group text-slate-600 bg-white hover:bg-slate-100 border border-slate-200"
                >
                  <HomeIcon className="w-5 h-5" />
                  <span className="ml-2 hidden sm:block">Home</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

export default GameHUD;