import React, { useState, useEffect } from 'react';
import { MemoryCard } from '../types';
import { LogoIcon } from './icons/LogoIcon';
import { StarIcon } from './icons/game-icons/StarIcon';
import { HeartIcon } from './icons/game-icons/HeartIcon';
import { SunIcon } from './icons/game-icons/SunIcon';
import { CloudIcon } from './icons/game-icons/CloudIcon';
import { LeafIcon } from './icons/game-icons/LeafIcon';
import { MoonIcon } from './icons/game-icons/MoonIcon';

const cardSymbols = [
    { key: 'star', Icon: StarIcon },
    { key: 'heart', Icon: HeartIcon },
    { key: 'sun', Icon: SunIcon },
    { key: 'cloud', Icon: CloudIcon },
    { key: 'leaf', Icon: LeafIcon },
    { key: 'moon', Icon: MoonIcon },
];

const generateDeck = (): MemoryCard[] => {
    const duplicatedSymbols = [...cardSymbols, ...cardSymbols];
    return duplicatedSymbols
        .map((symbol, index) => ({
            id: index,
            key: symbol.key,
            isFlipped: false,
            isMatched: false,
            Icon: symbol.Icon,
        }))
        .sort(() => Math.random() - 0.5);
};

const MemoryMatchGame: React.FC = () => {
    const [deck, setDeck] = useState<MemoryCard[]>(generateDeck());
    const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
    const [moves, setMoves] = useState(0);
    const [isGameWon, setIsGameWon] = useState(false);

    useEffect(() => {
        if (flippedIndices.length === 2) {
            const [firstIndex, secondIndex] = flippedIndices;
            const firstCard = deck[firstIndex];
            const secondCard = deck[secondIndex];

            if (firstCard.key === secondCard.key) {
                // It's a match
                setDeck(prevDeck =>
                    prevDeck.map(card =>
                        card.key === firstCard.key ? { ...card, isMatched: true } : card
                    )
                );
                setFlippedIndices([]);
            } else {
                // Not a match, flip back after a delay
                setTimeout(() => {
                    setDeck(prevDeck =>
                        prevDeck.map((card, index) =>
                            index === firstIndex || index === secondIndex ? { ...card, isFlipped: false } : card
                        )
                    );
                    setFlippedIndices([]);
                }, 1000);
            }
        }
    }, [flippedIndices, deck]);

    useEffect(() => {
        const allMatched = deck.every(card => card.isMatched);
        if (allMatched && deck.length > 0) {
            setIsGameWon(true);
        }
    }, [deck]);

    const handleCardClick = (index: number) => {
        if (flippedIndices.length === 2 || deck[index].isFlipped || deck[index].isMatched) {
            return; // Prevent flipping more than 2 or already matched/flipped cards
        }

        setDeck(prevDeck =>
            prevDeck.map((card, i) =>
                i === index ? { ...card, isFlipped: true } : card
            )
        );

        setFlippedIndices((prev) => {
            if (prev.length === 0) {
                setMoves((m) => m + 1);
            }
            return [...prev, index];
        });
    };
    
    const handleReset = () => {
        setDeck(generateDeck());
        setFlippedIndices([]);
        setMoves(0);
        setIsGameWon(false);
    }

    return (
        <div>
            <div className="flex justify-between items-center mb-6">
                <div className="text-right">
                    <p className="font-bold text-indigo-600 text-lg">{moves}</p>
                    <p className="text-sm text-slate-500">Moves</p>
                </div>
                 { !isGameWon &&
                    <button onClick={handleReset} className="bg-slate-200 text-slate-600 font-bold py-2 px-4 rounded-xl hover:bg-slate-300 transition-colors text-sm">
                        Reset
                    </button>
                 }
            </div>

            {isGameWon ? (
                <div className="flex flex-col items-center justify-center h-64">
                     <h3 className="text-2xl font-bold text-green-500 mb-4">You Won!</h3>
                     <p className="text-slate-600 mb-6">Great job exercising your mind!</p>
                     <button onClick={handleReset} className="bg-indigo-500 text-white font-bold py-3 px-6 rounded-xl hover:bg-indigo-600 transition-colors">
                        Play Again
                    </button>
                </div>
            ) : (
                <div className="grid grid-cols-4 gap-4">
                    {deck.map((card, index) => (
                        <div key={card.id} onClick={() => handleCardClick(index)} className="aspect-square cursor-pointer [perspective:1000px]">
                            <div className={`relative w-full h-full transition-transform duration-500 [transform-style:preserve-3d] ${card.isFlipped || card.isMatched ? '[transform:rotateY(180deg)]' : ''}`}>
                                {/* Back of card */}
                                <div className="absolute w-full h-full bg-indigo-400 rounded-lg flex items-center justify-center [backface-visibility:hidden]">
                                    <LogoIcon className="h-1/2 w-1/2 text-indigo-200" />
                                </div>
                                {/* Front of card */}
                                <div className={`absolute w-full h-full rounded-lg flex items-center justify-center [backface-visibility:hidden] [transform:rotateY(180deg)] ${card.isMatched ? 'bg-green-100' : 'bg-indigo-100'}`}>
                                    <card.Icon className={`h-3/4 w-3/4 ${card.isMatched ? 'text-green-500' : 'text-indigo-600'}`} />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default MemoryMatchGame;