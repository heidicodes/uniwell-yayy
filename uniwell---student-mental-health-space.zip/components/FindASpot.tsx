import React, { useState } from 'react';
import { Spot } from '../types';
import { CafeIcon } from './icons/CafeIcon';
import { PeopleIcon } from './icons/PeopleIcon';
import { OutdoorIcon } from './icons/OutdoorIcon';
import { SearchIcon } from './icons/SearchIcon';

const spots: Spot[] = [
  {
    name: 'The Campus Grind Cafe',
    description: 'A cozy spot with comfy chairs, great coffee, and a quiet buzz perfect for studying or catching up with a friend.',
    tags: ['Quiet', 'Study', 'Coffee'],
    icon: CafeIcon,
  },
  {
    name: 'Student Union Lounge',
    description: 'The heart of campus! A lively, social space with group seating, games, and always something happening.',
    tags: ['Social', 'Lively', 'Groups'],
    icon: PeopleIcon,
  },
  {
    name: 'Library Courtyard',
    description: 'An open-air oasis with benches and greenery. Ideal for reading, relaxing between classes, or quiet conversation.',
    tags: ['Outdoors', 'Quiet', 'Relax'],
    icon: OutdoorIcon,
  },
  {
    name: 'Hilltop Green Space',
    description: 'A large grassy area with a great view. Perfect for picnics, throwing a frisbee, or just soaking up some sun.',
    tags: ['Outdoors', 'Social', 'Active'],
    icon: OutdoorIcon,
  },
  {
    name: 'Creative Arts Building Atrium',
    description: 'A bright, inspiring space filled with natural light and student art. Great for creative thinking and quiet work.',
    tags: ['Quiet', 'Study', 'Inspiring'],
    icon: PeopleIcon,
  },
  {
    name: 'Corner Brews',
    description: 'A quick-service cafe near the science buildings, perfect for grabbing a drink and chatting with classmates.',
    tags: ['Coffee', 'Social', 'Quick'],
    icon: CafeIcon,
  },
];

const SpotCard: React.FC<{ spot: Spot }> = ({ spot }) => (
  <div className="bg-white rounded-2xl shadow-lg p-6 flex flex-col transition hover:shadow-xl hover:-translate-y-1 border border-slate-200">
    <div className="flex items-start space-x-4">
      <div className="flex-shrink-0 h-14 w-14 rounded-full bg-teal-100 flex items-center justify-center border-2 border-teal-200">
        <spot.icon className="h-7 w-7 text-teal-700" />
      </div>
      <div>
        <h3 className="text-lg font-bold text-slate-800">{spot.name}</h3>
        <p className="text-slate-600 mt-1">{spot.description}</p>
      </div>
    </div>
    <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap gap-2">
      {spot.tags.map(tag => (
        <span key={tag} className="text-xs font-semibold text-purple-800 bg-purple-100 inline-block px-3 py-1 rounded-full">
          {tag}
        </span>
      ))}
    </div>
  </div>
);

const FindASpot: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredSpots = spots.filter(spot => {
    const term = searchTerm.toLowerCase();
    return (
        spot.name.toLowerCase().includes(term) ||
        spot.description.toLowerCase().includes(term) ||
        spot.tags.some(tag => tag.toLowerCase().includes(term))
    );
  });

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="font-fredoka text-4xl font-bold mb-2 text-slate-800">Find a Spot</h1>
      <p className="text-slate-500 mb-6">Explore places on campus to study, relax, or meet new people.</p>
      
      <div className="relative mb-8">
        <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search for a spot, vibe, or tag..."
            className="w-full p-4 pl-12 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-400 focus:outline-none transition"
        />
        <div className="absolute inset-y-0 left-0 flex items-center pl-4 pointer-events-none">
            <SearchIcon className="w-6 h-6 text-slate-400" />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {filteredSpots.length > 0 ? (
          filteredSpots.map((spot, index) => (
            <SpotCard key={index} spot={spot} />
          ))
        ) : (
          <div className="md:col-span-2 text-center py-10 px-6 bg-white rounded-2xl shadow-lg border border-slate-200">
            <h3 className="text-xl font-bold text-slate-700">No Spots Found</h3>
            <p className="text-slate-500 mt-1">Try a different keyword like "quiet" or "coffee".</p>
         </div>
        )}
      </div>
    </div>
  );
};

export default FindASpot;