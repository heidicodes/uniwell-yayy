import React, { useState, useEffect } from 'react';
import GameHUD from './components/GameHUD';
import MoodCheckIn from './components/MoodCheckIn';
import AnonymousChat from './components/AnonymousChat';
import CampusResources from './components/CampusResources';
import Exercises from './components/Exercises';
import HabitTracker from './components/HabitTracker';
import HomePage from './components/HomePage';
import FindASpot from './components/FindASpot';

export type Page = 'home' | 'mood' | 'chat' | 'resources' | 'exercises' | 'habits' | 'spots';

const App: React.FC = () => {
  const [activePage, setActivePage] = useState<Page>('home');
  const [level, setLevel] = useState(1);
  const [xp, setXp] = useState(0);
  const [xpToNextLevel, setXpToNextLevel] = useState(100);

  useEffect(() => {
      if (xp >= xpToNextLevel) {
          setLevel(prevLevel => prevLevel + 1);
          setXp(prevXp => prevXp - xpToNextLevel);
          setXpToNextLevel(prev => Math.floor(prev * 1.5));
      }
  }, [xp, xpToNextLevel]);

  const addXp = (amount: number) => {
      setXp(prevXp => prevXp + amount);
  }

  const renderContent = () => {
    switch (activePage) {
      case 'home':
        return <HomePage setActivePage={setActivePage} />;
      case 'mood':
        return <MoodCheckIn addXp={addXp} />;
      case 'chat':
        return <AnonymousChat />;
      case 'resources':
        return <CampusResources />;
      case 'exercises':
        return <Exercises addXp={addXp} />;
      case 'habits':
        return <HabitTracker addXp={addXp} />;
      case 'spots':
        return <FindASpot />;
      default:
        return <HomePage setActivePage={setActivePage} />;
    }
  };

  return (
    <div className="bg-slate-50 text-slate-800 min-h-screen">
      <GameHUD 
        activePage={activePage}
        level={level}
        xp={xp}
        xpToNextLevel={xpToNextLevel}
        setActivePage={setActivePage} 
      />
      <main className="p-4 sm:p-6 md:p-8">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;