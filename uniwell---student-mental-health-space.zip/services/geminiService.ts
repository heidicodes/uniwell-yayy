import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { ChatMessage } from '../types';

// FIX: Per coding guidelines, the API key must be obtained directly from process.env.API_KEY.
// The variable is assumed to be pre-configured and valid.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

let chat: Chat;

function initializeChat() {
    chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
            systemInstruction: 'You are an empathetic and supportive mental health professional from a university wellness center. Your role is to listen, provide comfort, offer constructive coping strategies, and guide students to appropriate resources. You are speaking anonymously to a university student. Keep your responses concise, supportive, and helpful. Do not provide medical diagnoses. End your responses by gently encouraging the user to seek on-campus resources if their issue is serious.',
        },
    });
}

initializeChat();

export const getAIResponse = async (history: ChatMessage[], newUserMessage: string): Promise<string> => {
  try {
    // If the chat history is empty, it might be a new session.
    if (history.length === 0) {
        initializeChat();
    }
    
    const response: GenerateContentResponse = await chat.sendMessage({ message: newUserMessage });
    return response.text || "I'm not sure how to respond to that. Could you tell me more?";
  } catch (error) {
    console.error("Error getting AI response:", error);
    return "I'm having a little trouble connecting right now. Please try again in a moment.";
  }
};