// FIX: Import React to use React.ComponentType
import React from 'react';

export interface MoodLog {
  mood: 'awful' | 'bad' | 'okay' | 'good' | 'great';
  note: string;
  date: Date;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

export interface CampusResource {
  title: string;
  description: string;
  contact: string;
  icon: React.ComponentType<{ className?: string }>;
}

export interface Exercise {
  title: string;
  description: string;
  duration: string;
  content: string[];
}

export interface Habit {
  id: string;
  name: string;
  completions: Record<string, boolean>; // Key: 'YYYY-MM-DD', Value: boolean
}

export interface HabitCategory {
  title: string;
  habits: Habit[];
}

export interface JournalEntry {
    id: string;
    content: string;
    date: string;
}

export interface Spot {
  name: string;
  description: string;
  tags: string[];
  icon: React.ComponentType<{ className?: string }>;
}

// FIX: Add MemoryCard interface to resolve missing type error.
export interface MemoryCard {
  id: number;
  key: string;
  isFlipped: boolean;
  isMatched: boolean;
  Icon: React.ComponentType<{ className?: string }>;
}